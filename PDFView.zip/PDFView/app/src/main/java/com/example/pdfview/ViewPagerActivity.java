package com.example.pdfview;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import com.example.pdfview.adapter.ViewPageAdapter;

import java.util.ArrayList;
import java.util.List;

import androidx.viewpager2.widget.ViewPager2;

public class ViewPagerActivity extends AppCompatActivity {
   private ViewPager2 viewPager2;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewpager2);

        viewPager2 = findViewById(R.id.view_pager2);


        List<String> list = new ArrayList<>();

        list.add("First Screen");
        list.add("Second Screen");
        list.add("Third Screen");
        list.add("Fourth Screen");
        list.add("Fifth Screen");

        viewPager2.setAdapter(new ViewPageAdapter(this,list,viewPager2));


    }
}
